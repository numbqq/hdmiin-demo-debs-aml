/*
 * Copyright (c) 2019 Amlogic, Inc. All rights reserved.
 *
 * This source code is subject to the terms and conditions defined in the
 * file 'LICENSE' which is part of this source code package.
 *
 * Description:
 */

#ifndef _TVCLIENT_WRAPPER_H__
#define _TVCLIENT_WRAPPER_H_
#include <stdbool.h>
#include <stdlib.h>

#include "tvapi.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef enum event_type_e {
    TV_EVENT_TYPE_COMMOM = 0,
    TV_EVENT_TYPE_SCANNER,
    TV_EVENT_TYPE_EPG,
    TV_EVENT_TYPE_SOURCE_SWITCH,
    TV_EVENT_TYPE_SIGNAL_DETECT,
    TV_EVENT_TYPE_ADC_CALIBRATION,
    TV_EVENT_TYPE_VGA,
    TV_EVENT_TYPE_3D_STATE,
    TV_EVENT_TYPE_AV_PLAYBACK,
    TV_EVENT_TYPE_SERIAL_COMMUNICATION,
    TV_EVENT_TYPE_SOURCE_CONNECT,
    TV_EVENT_TYPE_HDMIRX_CEC,
    TV_EVENT_TYPE_BLOCK,
    TV_EVENT_TYPE_CC,
    TV_EVENT_TYPE_VCHIP,
    TV_EVENT_TYPE_HDMI_IN_CAP,
    TV_EVENT_TYPE_UPGRADE_FBC,
    TV_EVENT_TYPE_2d4G_HEADSET,
    TV_EVENT_TYPE_AV,
    TV_EVENT_TYPE_SUBTITLE,
    TV_EVENT_TYPE_SCANNING_FRAME_STABLE,
    TV_EVENT_TYPE_FRONTEND,
    TV_EVENT_TYPE_RECORDER,
    TV_EVENT_TYPE_RRT,
    TV_EVENT_TYPE_EAS,
    TV_EVENT_TYPE_AUDIO_CB,
    TV_EVENT_TYPE_SIG_DV_ALLM,
    TV_EVENT_TYPE_PIP_SIGNAL_DETECT,
    TV_EVENT_TYPE_MAX,
} event_type_t;

typedef struct {
    tv_source_input_t SourceInput;
    tvin_sig_fmt_t SignalFmt;
    tvin_trans_fmt_t TransFmt;
    tvin_sig_status_t SignalStatus;
    int isDviSignal; //1 is dvi signal
    unsigned int Hdrinfo;
} SignalDetectCallback_t;

typedef struct {
    tv_source_input_t SourceInput;
    int ConnectionState; //1 is connect
} SourceConnectCallback_t;

typedef struct {
    int allm_mode;
    int it_content;
    tvin_cn_type_t cn_type;
} SignalDvAllmCallback_t;

typedef struct {
  tv_source_input_t SourceInput;
  tvin_sig_fmt_t SignalFmt;
  tvin_trans_fmt_t TransFmt;
  tvin_sig_status_t SignalStatus;
  int isDviSignal; // 1 is dvi signal
  unsigned int Hdrinfo;
} PipSignalDetectCallback_t;

typedef void (*EventCallback)(event_type_t eventType, void *eventData);
EventCallback mEventCallback;

extern int setTvEventCallback(EventCallback Callback);

DECLARE_TVAPI_INTEFACES()

#ifdef __cplusplus
};
#endif

#endif
