/*
 * Copyright (C) 2014-present Amlogic, Inc. All rights reserved.
 *
 * All information contained herein is Amlogic confidential.
 *
 * This software is provided to you pursuant to Software License Agreement
 * (SLA) with Amlogic Inc ("Amlogic"). This software may be used
 * only in accordance with the terms of this agreement.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification is strictly prohibited without prior written permission from
 * Amlogic.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 * OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#pragma once

#include "TvCommon.h"
#include <stddef.h>

#define DECLARE_TVAPI_INTEFACES() \
  int StartTv(tv_source_input_t source); \
  int StopTv(tv_source_input_t source); \
  int SwitchSource(tv_source_input_t source); \
  tv_source_input_t GetCurrentSource(); \
  int SetEdidVersion(tv_source_input_t source, int edidVer); \
  int GetEdidVersion(tv_source_input_t source); \
  int SetEdidData(tv_source_input_t source, char *dataBuf); \
  int GetEdidData(tv_source_input_t source, char *dataBuf); \
  int SetVdinWorkMode(vdin_work_mode_t vdinWorkMode); \
  int GetCurrentSourceFrameHeight(); \
  int GetCurrentSourceFrameWidth(); \
  int GetCurrentSourceFrameFps(); \
  int GetCurrentSourceColorDepth(); \
  tvin_aspect_ratio_t GetCurrentSourceAspectRatio(); \
  tvin_color_fmt_t GetCurrentSourceColorFormat(); \
  tvin_color_range_t GetCurrentSourceColorRange(); \
  int SetCurrentSourceColorRange(tvin_color_range_t range_mode); \
  tvin_line_scan_mode_t GetCurrentSourceLineScanMode(); \
  int GetSourceConnectStatus(tv_source_input_t source); \
  int GetHdmiSPDInfo(tv_source_input_t source, char *dataBuf, size_t datalen); \
  int SetEdidBoostOn(int bBoostOn); \
  int GetCurrentSourceAllmInfo(struct tvin_latency_s *info); \
  int SetHdmiAllmEnabled(bool enable); \
  bool GetHdmiAllmEnabled(); \
  bool GetHdmiVrrSupport(); \
  int SetHdmiVrrEnabled(bool enable); \
  bool GetHdmiVrrEnabled(); \
  vdin_vrr_mode_t GetHdmiVrrMode(); \
  bool GetHdmiQmsSupport(); \
  int SetHdmiQmsEnabled(bool enable); \
  bool GetHdmiQmsEnabled(); \
  int GetCurrentStdInfo(struct tvin_std_s *info); \
  int SetAudioDecoderId(int channel, int id); \
  int SetAvAudioModeEnabled (bool enable); \
  int StartTvInPIP( tv_source_input_t source ); \
  int StopTvInPIP( tv_source_input_t source ); \
  int SetHdmiDlgEnabled(bool enable); \
  bool GetHdmiDlgEnabled(); \
  bool GetHdmiDlgSupport(void);
