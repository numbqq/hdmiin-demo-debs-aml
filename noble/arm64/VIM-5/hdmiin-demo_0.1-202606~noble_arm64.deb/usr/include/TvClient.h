/*
 * Copyright (c) 2019 Amlogic, Inc. All rights reserved.
 *
 * This source code is subject to the terms and conditions defined in the
 * file 'LICENSE' which is part of this source code package.
 *
 * Description:
 */

#pragma once

#include "CTvEvent.h"
#include "tvapi.h"

class TvClient {
public:
  class TvClientIObserver {
  public:
    TvClientIObserver(){};
    virtual ~TvClientIObserver(){};
    virtual void onTvClientEvent(CTvEvent &event) = 0;
  };

  void Release();
  static TvClient *GetInstance();
  int setTvClientObserver(TvClientIObserver *observer);

  TvClient(const TvClient &) = delete;
  void operator=(const TvClient &) = delete;

public:
  DECLARE_TVAPI_INTEFACES()
protected:
  ~TvClient();

private:
  // forbidden new tvclient
  TvClient();
};

