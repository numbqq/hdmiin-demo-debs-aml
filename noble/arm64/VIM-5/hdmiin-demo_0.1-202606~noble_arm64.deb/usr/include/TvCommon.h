/*
 * Copyright (c) 2019 Amlogic, Inc. All rights reserved.
 *
 * This source code is subject to the terms and conditions defined in the
 * file 'LICENSE' which is part of this source code package.
 *
 * Description:
 */
#ifndef __TV_COMMON_H__
#define __TV_COMMON_H__

#include <linux/amlogic/tvin.h>
#include <linux/amlogic/amvecm_ext.h>

#ifndef __TV_SOURCE_INPUT_TYPE__
#define __TV_SOURCE_INPUT_TYPE__
typedef enum tv_source_input_type_e {
    SOURCE_TYPE_TV,
    SOURCE_TYPE_AV,
    SOURCE_TYPE_COMPONENT,
    SOURCE_TYPE_HDMI,
    SOURCE_TYPE_VGA,
    SOURCE_TYPE_MPEG,
    SOURCE_TYPE_SVIDEO,
    SOURCE_TYPE_IPTV,
    SOURCE_TYPE_SPDIF,
    SOURCE_TYPE_MAX,
} tv_source_input_type_t;
#endif

typedef enum tvin_port_e tvin_port_t;
typedef enum tvin_aspect_ratio_e tvin_aspect_ratio_t;
typedef enum tvin_color_fmt_e tvin_color_fmt_t;
typedef enum tvin_sig_fmt_e tvin_sig_fmt_t;
typedef enum tvin_trans_fmt tvin_trans_fmt_t;
typedef enum tvin_sig_status_e tvin_sig_status_t;
typedef enum tvin_cn_type_e tvin_cn_type_t;
typedef enum vdin_vrr_mode_e vdin_vrr_mode_t;
typedef enum ve_source_input_e tv_source_input_t;

#ifndef __TVIN_WORK_MODE__
#define __TVIN_WORK_MODE__
typedef enum vdin_work_mode_e {
    VDIN_WORK_MODE_VFM = 0,
    VDIN_WORK_MODE_V4L2,
    VDIN_WORK_MODE_MAX,
} vdin_work_mode_t;
#endif

#ifndef __TVIN_COLOR_RANGE__
#define __TVIN_COLOR_RANGE__
typedef enum tvin_color_range_e {
    TVIN_COLOR_RANGE_AUTO = 0,
    TVIN_COLOR_RANGE_FULL,
    TVIN_COLOR_RANGE_LIMIT,
    TVIN_COLOR_RANGE_MAX,
} tvin_color_range_t;
#endif

#ifndef __TVIN_LINE_SCAN_MODE__
#define __TVIN_LINE_SCAN_MODE__
typedef enum tvin_line_scan_mode_e {
	TVIN_LINE_SCAN_MODE_NULL = 0,
	TVIN_LINE_SCAN_MODE_PROGRESSIVE,
	TVIN_LINE_SCAN_MODE_INTERLACED,
	TVIN_LINE_SCAN_MODE_MAX,
} tvin_line_scan_mode_t;
#endif

typedef enum tvin_cn_type_e tvin_cn_type_t;

// REAL_EDID_DATA_SIZE defined in libtv/CHDMIRxManager.h
#define REAL_EDID_DATA_SIZE        (256)
#define REAL_EDID_DATA_SIZE_MAX        (512)

#ifndef __TVIN_STD__
#define __TVIN_STD__
typedef struct tvin_std_s {
    int source;
    int edid_version;
    __u8 allm_enabled;
    __u8 vrr_enabled;
    __u8 qms_enabled;
}tvin_std_t;
#endif

#ifndef __TV_PATH_STATUS__
#define __TV_PATH_STATUS__
typedef enum tv_path_status_e {
    TV_PATH_STATUS_NO_DEV = -2,
    TV_PATH_STATUS_ERROR = -1,
    TV_PATH_STATUS_INACTIVE = 0,
    TV_PATH_STATUS_ACTIVE = 1,
    TV_PATH_STATUS_MAX,
} tv_path_status_t;
#endif

#ifndef __TV_CHANNEL__
#define __TV_CHANNEL__
typedef enum tv_channel_e {
    TV_CHANNEL_MAIN,
    TV_CHANNEL_SUB,
} tv_channel_t;
#endif

#endif
